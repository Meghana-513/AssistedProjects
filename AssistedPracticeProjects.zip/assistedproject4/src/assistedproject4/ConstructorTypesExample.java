package assistedproject4;

public class ConstructorTypesExample {
	  private String name;
	    private int age;

	    public ConstructorTypesExample() {
	        this.name = "John Doe";
	        this.age = 30;
	    }

	    public ConstructorTypesExample(String name, int age) {
	        this.name = name;
	        this.age = age;
	    }
	    
	    public ConstructorTypesExample(ConstructorTypesExample other) {
	        this.name = other.name;
	        this.age = other.age;
	    }

	    public String getName() {
	        return name;
	    }

	    public int getAge() {
	        return age;
	    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ConstructorTypesExample obj1 = new ConstructorTypesExample();
        ConstructorTypesExample obj2 = new ConstructorTypesExample("Alice", 25);
        ConstructorTypesExample obj3 = new ConstructorTypesExample(obj2);

        System.out.println("Object 1 - Name: " + obj1.getName() + ", Age: " + obj1.getAge());
        System.out.println("Object 2 - Name: " + obj2.getName() + ", Age: " + obj2.getAge());
        System.out.println("Object 3 - Name: " + obj3.getName() + ", Age: " + obj3.getAge());

	}

}