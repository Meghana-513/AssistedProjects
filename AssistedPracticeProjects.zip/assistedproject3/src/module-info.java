/**
 * 
 */
/**
 * 
 */
module assistedproject3 {
}