package assistedproject3;

public class MethodExample {
	public static void sayHello() {
        System.out.println("Hello!");
    }
	
    public static void greetPerson(String name) {
        System.out.println("Hello, " + name + "!");
    }

    public static int calculateSum(int a, int b) {
        int sum = a + b;
        return sum;
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		sayHello();
        String personName = "Alice";
        greetPerson(personName);

        int x = 5;
        int y = 3;
        int result = calculateSum(x, y);
        System.out.println("The sum of " + x + " and " + y + " is: " + result);

	}

}
