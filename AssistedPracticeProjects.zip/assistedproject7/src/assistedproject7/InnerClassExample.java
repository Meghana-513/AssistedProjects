package assistedproject7;

public class InnerClassExample {
	private String outerVariable = "Outer";

    // Inner class
    public class InnerClass {
        private String innerVariable = "Inner";

        public void display() {
            System.out.println("Inner class variable: " + innerVariable);
            System.out.println("Outer class variable: " + outerVariable);
        }
    }

    public static void main(String[] args) {
        InnerClassExample outerObject = new InnerClassExample();
        InnerClassExample.InnerClass innerObject = outerObject.new InnerClass();
        innerObject.display();
    }

}
