package assistedproject2;

public class AccessModifiersExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyClass obj = new MyClass();
        obj.publicMethod(); 
        System.out.println(obj.publicVariable);

        obj.protectedMethod(); 
        System.out.println(obj.protectedVariable);

        obj.defaultMethod(); 
        System.out.println(obj.defaultVariable);
    }
}

class MyClass {
    public int publicVariable = 10;
    protected int protectedVariable = 20;
    int defaultVariable = 30;
    private int privateVariable = 40;
    public void publicMethod() {
        System.out.println("This is a public method.");
    }

    protected void protectedMethod() {
        System.out.println("This is a protected method.");
    }

    void defaultMethod() {
        System.out.println("This is a default method.");
    }

    private void privateMethod() {
        System.out.println("This is a private method.");
  
	}

}