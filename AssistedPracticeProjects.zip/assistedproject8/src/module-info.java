/**
 * 
 */
/**
 * 
 */
module assistedproject8 {
}