package com.example.demo;

public class ProductException extends RuntimeException {

}
